<?php
include ('koneksi.php');
$db = new database();

?>

<!DOCTYPE html>
<html lang="en">

<head>
<title>Data Barang</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, minimun-scale=1 initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
    <title></title>
    <style type="text/css">
<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, minimum-scale=1,initial-scale=1">
        <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
        <style type="text/css">
            form#background_border{
            margin: 0px 500px;
            color:black;
            }
            form#print_satuan{
            margin: 20px 200px;
            color:white;
            }
            .posisi_tombol{
            margin: 0px 200px;	  
            }
            .tombol_login{
            background: #47C0DB;
            color: white;
            font-size: 11pt;
            border: none;
            padding: 5px 20px;
            }
            .pagination {
            display: inline-block;
            position: relative;
            /* Move the element to the right by 50% of the container's width */
            left: 50%; 
            /* Calculates 50% of the element's width, and moves it by that */ 
            /* amount across the X-axis to the left */
            transform: translateX(-50%);
            }

            .pagination a {
            color: black;
            float: left;
            padding: 10px 20px;
            text-decoration: none;
            }

            .pagination a.active {
            background-color: #FFFFFF;
            color: black;
            border-radius: 10px;
            }

            .pagination a:hover:not(.active) {
            background-color: #ddd;
            border-radius: 10px;
            }
        </style>
	
        <style>
            .autocomplete-suggestions {
                border: 1px solid #999;
                background: #FFF;
                overflow: auto;
            }
            .autocomplete-suggestion {
                padding: 2px 5px;
                white-space: nowrap;
                overflow: hidden;
            }
            .autocomplete-selected {
                background: #F0F0F0;
            }
            .autocomplete-suggestions strong {
                font-weight: normal;
                color: #3399FF;
            }
            .autocomplete-group {
                padding: 2px 5px;
            }
            .autocomplete-group strong {
                display: block;
                border-bottom: 1px solid #000;
            }
    </style>
	
	<style type="text/css">
      * {
        font-family: "Trebuchet MS";
      }
      h1 {
        text-transform: uppercase;
        color: #47C0DB;
      }
    table {
      border: solid 1px #DDEEEE;
      border-collapse: collapse;
      border-spacing: 0;
      width: 70%;
      margin: 10px auto 10px auto;
    }
    table thead th {
        background-color: #DDEFEF;
        border: solid 1px #DDEEEE;
        color: #336B6B;
        padding: 10px;
        text-align: left;
        text-shadow: 1px 1px 1px #fff;
        text-decoration: none;
    }
    table tbody td {
        border: solid 1px #DDEEEE;
        color: #333;
        padding: 10px;
        text-shadow: 1px 1px 1px #fff;
    }
    a {
          background-color: #47C0DB;
          color: #fff;
          padding: 10px;
          text-decoration: none;
          font-size: 12px;
    }
    </style>
	
        <style>
        body {
        font-family: Arial, Helvetica, sans-serif;
        }

        .navbar {
        overflow: hidden;
        background-color: #47C0DB;
        }

        .navbar a {
        float: left;
        font-size: 16px;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        }

        .dropdown {
        float: left;
        overflow: hidden;
        }

        .dropdown .dropbtn {
        font-size: 16px;  
        border: none;
        outline: none;
        color: white;
        padding: 14px 16px;
        background-color: inherit;
        font-family: inherit;
        margin: 0;
        }

        .navbar a:hover, .dropdown:hover .dropbtn {
        background-color: azure;
        color: black;
        }

        .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
        }

        .dropdown-content a {
        float: none;
        color: white;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
        }

        .dropdown-content a:hover {
        background-color: #ddd;
        }

        .dropdown:hover .dropdown-content {
        display: block;
        }
    </style>

</head>

<body>
    <div class="navbar">
        <a href="index.php">Home</a>
        <div class="dropdown">
            <button class="dropbtn">Kelola Data 
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
            <a href="gudang/gudang.php">Data Gudang</a>
            <a href="tampil.php">Data Barang</a>
            <a href="customer/customer.php">Data Customer</a>
            <a href="supplier/supplier.php">Data Suppllier</a>
            </div>
    </div>
    <div class="dropdown">
            <button class="dropbtn">Kelola Transaksi 
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
            <a href="">Transaksi Pembelian</a>
            <a href="tampil.php">Transaksi Penjualan</a>
            </div>
    </div>
    <div class="dropdown">
            <button class="dropbtn">Kelola Laporan
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
            <a href=""></a>
            <a href="tampil.php">Laporan Transaksi Penjualan</a>
            <a href="tampil.php">Laporan Transaksi Pembelian</a>
            </div>
    </div>
        <a href="login.php">Logout</a>
    </div>

    <form id="background_border" method="get">
        Cari Berdasarkan :
        <select name="kriteria">
            <option value="kode_barang">Kode Barang</option>
            <option value="nama_barang">Nama Barang</option>
            <option value="stok">Stok</option>
            <option value="harga_beli">Harga Beli</option>
            <option value="harga_jual">Harga Jual</option>
        </select>
        <input type="text" name="cari" placeholder="Cari Data">
        <input type="submit" class="tombol_login" value="Cari">
    </form>
    <br>

    <div class="posisi_tombol">
        <a href="tambah_data.php">+ Tambah Data</a>&nbsp;&nbsp;
        <a href="cetak.php" target="_BLANK">Print Data Barang</a>
    </div>

    <br>

    <div class="posisi_tombol">
        <form method="post" action="cetak_satuan.php" target="_blank">
            <input type="text" id="nama_barang" name="kode_barang" placeholder="Nama Barang" value="">
            <input type="submit" value="Print Satuan"
                style="background-color:#47C0DB;color:#fff;padding:10px;text-decoration:none;font-size:12px;border:none;">
        </form>
        <script src="jquery-3.2.1.min.js"></script>
        <script src="jquery.autocomplete.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#nama_barang").autocomplete({
                    serviceUrl: "source.php",
                    dataType: "JSON",
                    onSelect: function (suggestion) {
                        $("#nama_barang").val("" + suggestion.nama_barang);

                    }
                })
            })
        </script>

    </div>
            
    <center>
        <h1>Data Barang</h1>
    </center>
    <table width="65%" border="1">
        <thead>
            <tr>
                <th width="6%">No</th>
                <th width="16%">Kode Barang</th>
                <th width="15%">Nama Barang</th>
                <th width="7%">Stok</th>
                <th width="13%">Harga Beli</th>
                <th width="14%">Harga Jual</th>
                <th width="16%">Gambar Produk</th>
                <th width="13%">Action</th>
            </tr>
        </thead>

        <?php
        $data_barang = [];
        $item = 5; // Number of items per page
        $page = isset($_GET["halaman"]) ? (int)$_GET["halaman"] : 1;
        $start = ($page > 1) ? ($page * $item) - $item : 0;
        if (isset($_GET['cari'])) {
            $cari = $_GET['cari'];
            $kriteria = $_GET['kriteria'];
            $data_barang = $db->cari_data($cari, $kriteria);
        } else {
            $data_barang_result = $db->tampil_data();
            $total_rows = count($data_barang_result);
            $total_pages = ceil($total_rows / $item);
            $data_barang = $db->page($start, $item);
        }

        $no = ($page - 1) * $item + 1;
        foreach ($data_barang as $row) {
            $rupiah_harga_beli = "Rp " . number_format($row['harga_beli'], 2, ',', '.');
            $rupiah_harga_jual = "Rp " . number_format($row['harga_jual'], 2, ',', '.');
        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $row['kode_barang']; ?></td>
            <td><?php echo $row['nama_barang']; ?></td>
            <td><?php echo $row['stok']; ?></td>
            <td><?php echo $rupiah_harga_beli; ?></td>
            <td><?php echo $rupiah_harga_jual; ?></td>
            <td style="text-align: center;"><img src="gambar/<?php echo $row['gambar_produk']; ?>"
                    style="width: 120px;"></td>
            <td>
                <a href="edit_data.php?id_barang=<?php echo $row['id_barang']; ?>&action=edit">Edit</a>
                <a href="proses_barang.php?id_barang=<?php echo $row['id_barang']; ?>&action=delete">Hapus</a>
            </td>
        </tr>
        <?php } ?>
    </table>

    <?php
        if (isset($_GET['cari'])){
            $cari = $_GET['cari'];
            echo "<b>Hasil Pencarian : ".$cari."</b>";
        }
        ?>
    <br>
    <br>

    <div class="tombol_page">
        <?php if ($page > 1): ?>
        <a href="?halaman=<?php echo ($page - 1); ?>">Previous</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++) { ?>
        <a href="?halaman=<?php echo $i; ?>" <?php echo ($i === $page) ? 'class="active"' : ''; ?>><?php echo $i; ?></a>
        <?php } ?>

        <?php if ($page < $total_pages): ?>
        <a href="?halaman=<?php echo ($page + 1); ?>">Next</a>
        <?php endif; ?>
    </div>

</body>

<?php
?>

</html>