<?php
include('koneksi.php');
$koneksi = new database();

$action = $_GET['action'];

if($action == "add") {
    $koneksi->tambah_data($_POST['nota'], $_POST['nama_beli'], $_POST['alamat_beli'], $_POST['telepon_beli'], $_POST['email_beli'], $_POST['pass_beli']);
    header('location:beli.php');
} else if ($action == "edit") {
    $nota = $_GET['nota'];
    $koneksi->edit_data($nota, $_POST['nama_beli'], $_POST['alamat_beli'], $_POST['telepon_beli'], $_POST['email_beli'], $_POST['pass_beli']);
    header('location:beli.php');
} else if ($action == "delete") {
    $nota = $_GET['nota'];
    $koneksi->delete_data($nota);
    header('location:beli.php');
} 
?>
