<?php
include('koneksi.php'); 

$db = new database(); 

$notas = $db->nota();
$nota_terakhir = '';

foreach ($notas as $row) {
    $kode_max = $row['nota'];
    $pecahdata = explode('NOTA', $kode_max);
    $kode_number = (int)$pecahdata[1];

    // Menambahkan angka 1 ke kode terakhir
    $next_number = $kode_number + 1;

    // Mengonversi angka menjadi string dengan tetap mempertahankan panjangnya
    $next_code = 'NOTA' . sprintf("%02d", $next_number); // Ubah ke format ID yang diinginkan

    // Simpan kode supplier terakhir
    $nota_terakhir = $next_code;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Form Transaksi Beli</title>
</head>
<body>
    <h3>Form Transaksi Beli</h3>
    <hr/>
    <form method="post" action="proses_transaksi.php?action=add">
        <table>
        <tr>
            <td>Nota</td>
            <td>:</td>
            <td>
            <input type="text" name="nota" value="<?php echo $nota_terakhir; ?>" readonly/></td>
        </tr>
        <tr>
            <td>Nama Pemasok</td>
            <td>:</td>
            <td>
            <input type="text" name="nama_pemasok"></td>
        </tr>
        <tr>
            <td>Nama Barang</td>
            <td>:</td>
            <td>
            <input type="text" name="nama_barang" ></td>
        </tr>
        <tr>
            <td>Harga Satuan</td>
            <td>:</td>
            <td>
            <input type="text" name="harga_satuan" ></td>
        </tr>
        <tr>
            <td>Qty</td>
            <td>:</td>
            <td>
            <input type="text" name="qty" ></td>
        </tr>
            <tr>
                <td></td>
                <td></td>
                <td>
                    <input type="submit" name="tombol" value="Simpan"/>
                    <a href="supplier.php">
                        <input type="button" name="tombol" value="Kembali"/>
                    </a>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
