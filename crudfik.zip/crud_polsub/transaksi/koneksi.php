<?php
class database {
    var $host = "localhost";
    var $username = "root";
    var $password = "";
    var $database = "belajar_oop";
    var $koneksi = "";

    function __construct() {
        $this->koneksi = mysqli_connect($this->host, $this->username, $this->password, $this->database);
        if (mysqli_connect_error()) {
            echo "Koneksi database gagal : " . mysqli_connect_error();
        }
    }
    function cek_login($username, $password) {
        $query = "SELECT * FROM user WHERE username = ?"; // Query untuk mendapatkan data user berdasarkan username
        $stmt = $this->koneksi->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                return $user; // Mengembalikan data user jika login berhasil
            }
        }
        return null; // Mengembalikan null jika login gagal
    }

    function tampil_data(){
        $data = mysqli_query($this->koneksi,"select * from tb_transaksi");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }

    function tambah_data($nota, $nama_pemasok, $nama_barang, $harga_satuan, $qty, $gudang_tujuan){
        mysqli_query($this->koneksi,"insert into tb_transaksi values ('$nota', '$nama_pemasok', '$nama_barang', '$harga_satuan', '$qty', '$gudang_tujuan')");
    }
    
    function tampil_edit_data($nota){
        $data = mysqli_query($this->koneksi,"select * from tb_transaksi where nota ='$nota'");
        while($d = mysqli_fetch_array($data)){
            $hasil[] = $d;
        }
        return $hasil;
    }
    
    function edit_data( $nama_pemasok, $nama_barang, $harga_satuan, $qty, $gudang_tujuan){
        mysqli_query($this->koneksi,"update tb_transaksi set nama_pemasok='$nama_pemasok', nama_barang ='$nama_barang', harga_satuan='$harga_satuan', qty='$qty' where nota='$nota'");
    }
    
    function delete_data($nota){
        mysqli_query($this->koneksi, "delete from tb_transaksi where nota='$nota'");
    }
    
    function cari_data($nama_supplier){
        $data = mysqli_query($this->koneksi,"select * from tb_transaksi where nama_supplier='$nama_supplier'");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    
    function nota() {
        $data = mysqli_query($this->koneksi, "SELECT nota FROM tb_transaksi ORDER BY nota DESC LIMIT 1");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    
    
    function tampil_data_cari($nama_supplier){
        $data = mysqli_query($this->koneksi, "select * from tb_transaksi where nama_supplier like '%$nama_supplier%'");
        $hasil = [];
        while ($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    
    function cetak_data($nota) {
        $query = "SELECT * FROM tb_transaksi WHERE nota = '$nota'";
        $data = mysqli_query($this->koneksi, $query);
        return $data;
    }
    
    function tampil_datas(){
        $data = mysqli_query($this->koneksi,"SELECT * FROM tb_transaksi");
        while($row = mysqli_fetch_assoc($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    
}

?>

