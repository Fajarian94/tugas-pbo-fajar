<?php
include('koneksi.php');
$db = new database();
$nota = $_GET['nota'];
$data_edit_beli = $db->tampil_edit_data($nota);

?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <h3>Form Edit Data beli</h3>
    <hr/>
    <form method="post" action="proses_tansaksi.php?action=edit&nota=<?php echo $nota;?>">
    <?php
    foreach($data_edit_beli as $d){
    ?>
    <table>
        <tr>
            <td>Nota</td>
            <td>:</td>
            <td>
            <input type="text" name="nota" value="<?php echo $d['nota']; ?>"readonly/></td>
        </tr>
        <tr>
            <td>Nama Pemasok</td>
            <td>:</td>
            <td>
            <input type="text" name="nama_pemasok" value="<?php echo $d['nama_pemasok']; ?>"></td>
        </tr>
        <tr>
            <td>Nama Barang</td>
            <td>:</td>
            <td>
            <input type="text" name="nama_barang" value="<?php echo $d['nama_barang']; ?>"></td>
        </tr>
        <tr>
            <td>Harga Satuan</td>
            <td>:</td>
            <td>
            <input type="text" name="harga_satuan" value="<?php echo $d['harga_satuan']; ?>"></td>
        </tr>
        <tr>
            <td>Qty</td>
            <td>:</td>
            <td>
            <input type="text" name="qty" value="<?php echo $d['qty']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td>
            <input type="submit" name="tombol" value="Ubah"/>
            <a href="beli.php">
            <input type="submit" name="tombol" value="Kembali"/>
            </a>
        </td>
        </tr>
    </table>
    <?php
    }
    ?>
</form>
</body>
</html>