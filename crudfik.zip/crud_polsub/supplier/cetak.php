<?php
include('koneksi.php');
$db = new database();
?>
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <style type = "text/css">
            from#background_border{
                margin:0px 230px;
                color:white
            }

        </style>
    </head>
    <body>
        <h2>LAPORAN DATA BARANG CV JAYA</h2>
        <table width="667"  border="1">
            <tr>
                <th width="21">ID Supplier</th>
                <th width="122">Nama Supplier</th>
                <th width="158">Alamat Supplier</th>
                <th width="47">Telepon Supplier</th>
                <th width="76">Email Supplier</th>
                <th width="83">Password Supplier</th>
            </tr>
            <?php
            $data_barang = $db->tampil_data();
            $no = 1;
            foreach($data_barang as $row){
            ?>
                <tr>
                    <td><?php echo $row['id_supplier']; ?></td>
                    <td><?php echo $row['nama_supplier']; ?></td>
                    <td><?php echo $row['alamat_supplier']; ?></td>
                    <td><?php echo $row['telepon_supplier']; ?></td>
                    <td><?php echo $row['email_supplier']; ?></td>
                    <td><?php echo $row['pass_supplier']; ?></td>
                    <td>
                        <a href="edit_data.php?id_barang=<?php echo $row['id_barang']; ?>&action=edit">Edit</a>
                        <a href="proses_supplier.php?id_barang=<?php echo $row['id_barang']; ?>&action=delete">Hapus</a>
                    </td>
                </tr>
            <?php
            } ?>
        </table>
        <script>
            window.print();
        </script>
        <tr>
        <a href="barang.php">
        <input type="button" name="tombol" value="Kembali"/>
        </a>
        </td>
        </tr>
    </body>
</html>