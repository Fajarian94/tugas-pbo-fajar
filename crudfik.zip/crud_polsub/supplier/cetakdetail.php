<?php
include('koneksi.php');
$db = new database();

if (isset($_POST['cetak'])) {
    $kode_barang = $_POST['cetak'];
    $data_barang = $db->cari_datas($kode_barang); // Mengambil data berdasarkan kode barang

    if ($data_barang) {
        // Jika data ditemukan, tampilkan informasi
        echo "<h2>Detail Barang</h2>";
        foreach ($data_barang as $row) {['id_supplier'] . "</p>";
            echo "<p>Nama Supplier: " . $row['nama_supplier'] . "</p>";
            echo "<p>Alamat Supplier: " . $row['telepon_supplier'] . "</p>";
            echo "<p>Email Supplier: " . $row['email_supplier'] . "</p>";
            echo "<p>Password Supplier: " . $row['pass_supplier'] . "</p>";
        }
        
        // Tombol untuk mencetak
        echo "<button onclick='window.print()'>Cetak</button>";

    } else {
        // Jika tidak ada data ditemukan
        echo "<p>Data tidak ditemukan untuk kode barang '$kode_barang'.</p>";
    }
}
?>
