<?php
class database {
    var $host = "localhost";
    var $username = "root";
    var $password = "";
    var $database = "belajar_oop";
    var $koneksi = "";

    function __construct() {
        $this->koneksi = mysqli_connect($this->host, $this->username, $this->password, $this->database);
        if (mysqli_connect_error()) {
            echo "Koneksi database gagal : " . mysqli_connect_error();
        }
    }
    function cek_login($username, $password) {
        $query = "SELECT * FROM user WHERE username = ?"; // Query untuk mendapatkan data user berdasarkan username
        $stmt = $this->koneksi->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                return $user; // Mengembalikan data user jika login berhasil
            }
        }
        return null; // Mengembalikan null jika login gagal
    }

    function tampil_data(){
        $data = mysqli_query($this->koneksi,"select * from tb_supplier");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }

    function tambah_data($id_supplier, $nama_supplier, $alamat_supplier, $telepon_supplier, $email_supplier, $pass_supplier){
        mysqli_query($this->koneksi,"insert into tb_supplier values ('$id_supplier', '$nama_supplier', '$alamat_supplier', '$telepon_supplier', '$email_supplier', '$pass_supplier')");
    }
    
    function tampil_edit_data($id_supplier){
        $data = mysqli_query($this->koneksi,"select * from tb_supplier where id_supplier ='$id_supplier'");
        while($d = mysqli_fetch_array($data)){
            $hasil[] = $d;
        }
        return $hasil;
    }
    
    function edit_data($id_supplier, $nama_supplier, $alamat_supplier, $telepon_supplier, $email_supplier, $pass_supplier){
        mysqli_query($this->koneksi,"update tb_supplier set nama_supplier='$nama_supplier', alamat_supplier ='$alamat_supplier', telepon_supplier='$telepon_supplier', email_supplier='$email_supplier', pass_supplier='$pass_supplier' where id_supplier='$id_supplier'");
    }
    
    function delete_data($id_supplier){
        mysqli_query($this->koneksi, "delete from tb_supplier where id_supplier='$id_supplier'");
    }
    
    function cari_data($nama_supplier){
        $data = mysqli_query($this->koneksi,"select * from tb_supplier where nama_supplier='$nama_supplier'");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    
    function kode_supplier() {
        $data = mysqli_query($this->koneksi, "SELECT id_supplier FROM tb_supplier ORDER BY id_supplier DESC LIMIT 1");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    
    function cari_datas($id_supplier){
        $query = "SELECT * FROM tb_supplier WHERE id_supplier = '$id_supplier'";
        $data = mysqli_query($this->koneksi, $query);
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    
    function tampil_data_cari($nama_supplier){
        $data = mysqli_query($this->koneksi, "select * from tb_supplier where nama_supplier like '%$nama_supplier%'");
        $hasil = [];
        while ($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    
    function cetak_data($id_supplier) {
        $query = "SELECT * FROM tb_supplier WHERE id_supplier = '$id_supplier'";
        $data = mysqli_query($this->koneksi, $query);
        return $data;
    }
    
    function tampil_datas(){
        $data = mysqli_query($this->koneksi,"SELECT * FROM tb_supplier");
        while($row = mysqli_fetch_assoc($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    
}

?>

