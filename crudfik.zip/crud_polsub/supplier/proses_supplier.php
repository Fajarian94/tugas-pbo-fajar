<?php
include('koneksi.php');
$koneksi = new database();

$action = $_GET['action'];

if($action == "add") {
    $koneksi->tambah_data($_POST['id_supplier'], $_POST['nama_supplier'], $_POST['alamat_supplier'], $_POST['telepon_supplier'], $_POST['email_supplier'], $_POST['pass_supplier']);
    header('location:supplier.php');
} else if ($action == "edit") {
    $id_supplier = $_GET['id_supplier'];
    $koneksi->edit_data($id_supplier, $_POST['nama_supplier'], $_POST['alamat_supplier'], $_POST['telepon_supplier'], $_POST['email_supplier'], $_POST['pass_supplier']);
    header('location:supplier.php');
} else if ($action == "delete") {
    $id_supplier = $_GET['id_supplier'];
    $koneksi->delete_data($id_supplier);
    header('location:supplier.php');
} else if ($action == "search") {
    $nama_supplier = $_POST['nama_supplier'];
    $koneksi->cari_data($nama_supplier);
    header('location:supplier.php');
}
?>
