<?php
include('koneksi.php'); 

$db = new database(); 

$kode_suppliers = $db->kode_supplier();
$kode_supplier_terakhir = '';

foreach ($kode_suppliers as $row) {
    $kode_max = $row['id_supplier'];
    $pecahdata = explode('SUPP', $kode_max);
    $kode_number = (int)$pecahdata[1];

    // Menambahkan angka 1 ke kode terakhir
    $next_number = $kode_number + 1;

    // Mengonversi angka menjadi string dengan tetap mempertahankan panjangnya
    $next_code = 'SUPP' . sprintf("%04d", $next_number); // Ubah ke format ID yang diinginkan

    // Simpan kode supplier terakhir
    $kode_supplier_terakhir = $next_code;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Form Tambah Data Supplier</title>
</head>
<body>
    <h3>Form Tambah Data Supplier</h3>
    <hr/>
    <form method="post" action="proses_supplier.php?action=add">
        <table>
            <tr>
                <td>ID Supplier</td>
                <td>:</td>
                <td><input type="text" name="id_supplier" value="<?php echo $kode_supplier_terakhir; ?>" readonly/></td>
            </tr>
            <tr>
                <td>Nama Supplier</td>
                <td>:</td>
                <td><input type="text" name="nama_supplier"/></td>
            </tr>
            <tr>
                <td>Alamat Supplier</td>
                <td>:</td>
                <td><input type="text" name="alamat_supplier"/></td>
            </tr>
            <tr>
                <td>Telepon Supplier</td>
                <td>:</td>
                <td><input type="text" name="telepon_supplier"/></td>
            </tr>
            <tr>
                <td>Email Supplier</td>
                <td>:</td>
                <td><input type="text" name="email_supplier"/></td>
            </tr>
            <tr>
                <td>Password Supplier</td>
                <td>:</td>
                <td><input type="text" name="pass_supplier"/></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td>
                    <input type="submit" name="tombol" value="Simpan"/>
                    <a href="supplier.php">
                        <input type="button" name="tombol" value="Kembali"/>
                    </a>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
