<?php
include('koneksi.php');
$db = new database();
$id_barang = $_GET['id_supplier'];
$data_edit_barang = $db->tampil_edit_data($id_supplier);

?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <h3>Form Edit Data Supplier</h3>
    <hr/>
    <form method="post" action="proses_supplier.php?action=edit&id_supplier=<?php echo $id_supplier;?>">
    <?php
    foreach($data_edit_barang as $d){
    ?>
    <table>
        <tr>
            <td>ID Supplier</td>
            <td>:</td>
            <td>
            <input type="text" name="id_supplier" value="<?php echo $d['nama_barang']; ?>"></td>
        </tr>
        <tr>
            <td>Nama Supplier</td>
            <td>:</td>
            <td>
            <input type="text" name="nama_supplier" value="<?php echo $d['nama_barang']; ?>"></td>
        </tr>
        <tr>
            <td>Alamat Supplier</td>
            <td>:</td>
            <td>
            <input type="text" name="alamat_supplier" value="<?php echo $d['stok']; ?>"></td>
        </tr>
        <tr>
            <td>Telepon Supplier</td>
            <td>:</td>
            <td>
            <input type="text" name="telepon_supplier" value="<?php echo $d['harga_beli']; ?>"></td>
        </tr>
        <tr>
            <td>Email Supplier</td>
            <td>:</td>
            <td>
            <input type="text" name="email_supplier" value="<?php echo $d['harga_jual']; ?>"></td>
        </tr>
        <tr>
            <td>Password Supplier</td>
            <td>:</td>
            <td>
            <input type="text" name="pass_supplier" value="<?php echo $d['pass_jual']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td>
            <input type="submit" name="tombol" value="Ubah"/>
            <a href="tampil_data.php">
            <input type="submit" name="tombol" value="Kembali"/>
            </a>
        </td>
        </tr>
    </table>
    <?php
    }
    ?>
</form>
</body>
</html>