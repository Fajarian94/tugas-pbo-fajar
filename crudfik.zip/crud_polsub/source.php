<?php
header("Content-Type: application/json; charset=UTF-8");

$host = "localhost";
$username = "root";
$password = "";
$database = "belajar_oop";

$con = new mysqli($host, $username, $password, $database);

$nama_barang = $_GET["query"];
$query = $con->query("SELECT * FROM tb_barang WHERE nama_barang like '%$nama_barang%' ORDER BY nama_barang");
$result = $query->fetch_all(MYSQLI_ASSOC);

$output = ['suggestions' => []];

if (count($result) > 0) {
    foreach ($result as $data) {
        $output['suggestions'][] = [
            'value' => $data['nama_barang'],
            'nama_barang' => $data['nama_barang']
        ];
    }
} else {
    $output['suggestions'][] = [
        'value' => '',
        'nama_barang' => ''
    ];
}

echo json_encode($output);
?>
