<?php

    include ('koneksi.php');
    $db = new database();

?>


<html lang="en">

<head>

    <title></title>

    <style type="text/css">
        form#background_border {
            margin: 0px 230px;
            color: white;
        }
    </style>

</head>

<body>

    <h2>LAPORAN DATA BARANG CV POLSUB</h2>

    <table width="667" border="1">
        <tr>
            <th width="21">NO</th>
            <th width="122">KODE BARANG</th>
            <th width="158">BARANG</th>
            <th width="47">STOK</th>
            <th width="76">HARGA BELI</th>
            <th width="83">HARGA JUAL</th>
            <th width="114">KEUNTUNGAN</th>
        </tr>

        <?php
            $data_barang = $db -> tampil_data();
            $no = 1;
            foreach ($data_barang as $row){    
            ?>

        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $row['kode_barang']; ?></td>
            <td><?php echo $row['nama_barang']; ?></td>
            <td><?php echo $row['stok']; ?></td>
            <td><?php echo $row['harga_beli']; ?></td>
            <td><?php echo $row['harga_jual']; ?></td>
            <td><?php echo $row['harga_jual'] - $row['harga_beli']; ?></td>
        </tr>
        <?php
            }?>
    </table>

    <script>
        window.print();
    </script>

<?php
##ALL LICENSE RESERVED TO MUTABIT, TOLONG INGAT INI
##ALL LICENSE RESERVED TO MUTABIT, TOLONG INGAT INI
?>
</body>

</html>