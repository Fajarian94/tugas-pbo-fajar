<?php
    include ('koneksi.php');
    $db = new database();
    $kode_barang = $_POST['kode_barang'];
    $data_barang = $db->cetak_satuan($kode_barang);
?>


<html lang="en">

<head>

    <title></title>

    <style type="text/css">
        form#background_border {
            margin: 0px 230px;
            color: white;
        }
    </style>

</head>

<body>
    <?php
            foreach ($data_barang as $row){    
        ?>
    <h2>LAPORAN DETAIL DATA BARANG CV POLSUB : <?php echo $row['nama_barang']; ?> </h2>

    <table width="667" border="1">



        <tr>
            <td>KODE BARANG</td>
            <td>:</td>
            <td><?php echo $row['kode_barang']; ?></td>
        </tr>

        <tr>
            <td>NAMA BARANG</td>
            <td>:</td>
            <td><?php echo $row['nama_barang']; ?></td>
        </tr>

        <tr>
            <td>STOK</td>
            <td>:</td>
            <td><?php echo $row['stok']; ?></td>
        </tr>

        <tr>
            <td>HARGA BELI</td>
            <td>:</td>
            <td><?php echo $row['harga_beli']; ?></td>
        </tr>

        <tr>
            <td>HARGA JUAL</td>
            <td>:</td>
            <td><?php echo $row['harga_jual']; ?></td>
        </tr>

        <tr>
            <td>KEUNTUNGAN</td>
            <td>:</td>
            <td><?php echo $row['harga_jual'] - $row['harga_beli']; ?></td>
        </tr>

        <?php
            }
            ?>
    </table>

    <script>
        window.print();
    </script>

    <?php
##ALL LICENSE RESERVED TO MUTABIT, TOLONG INGAT INI
##ALL LICENSE RESERVED TO MUTABIT, TOLONG INGAT INI
?>
</body>

</html>