<?php
session_start();

include('koneksi.php');
$db = new database();
$loggedIn = false;

function authenticateUser($username, $password) {
    // Kode autentikasi
    $mysqli = new mysqli('localhost', 'root', '', 'belajar_oop');

    if ($mysqli->connect_error) {
        die('Koneksi database gagal: ' . $mysqli->connect_error);
    }

    $query = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";
    $result = $mysqli->query($query);

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id_user'];
        return true;
    } else {
        return false;
    }

    $mysqli->close();
}

function logoutUser() {
    session_unset();
    session_destroy();
    header('Location: index.php');
}

if (isset($_SESSION['user_id'])) {
    $loggedIn = true;
}

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (authenticateUser($username, $password)) {
        $loggedIn = true;
        header('Location: index.php');
        exit();
    }
}

if (isset($_POST['logout'])) {
    logoutUser();
}

// Perubahan: Menambahkan pengecekan jika belum login, maka langsung arahkan ke halaman login
if (!$loggedIn) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Beranda</title>
    <style type="text/css">
        form#background_border{
            margin: 0px 500px;
            color:black;
        }
        .button-group {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .button-group > * {
            margin-right: 10px;
            align: center;
        }
        *{
            font-family:"Trebuchat MS";
        }
        h1 {
            text-transform : uppercase;
            color: #47C0DB;
            text-align: center;
        }
        table{
            border: solid 1px = #DDEEEE;
            border-collapse: collapse;
            border-spacing: 0;
            width 70%;
            margin: 10px auto 10x auto;
        }
        th {
            background-color: #DDEFEF;
            border: solid 1px #DDEEEE;
            color: #336B6B;
            padding: 10px;
            text-align: left;
            text-shadow: 1px 1px 1px #fff;
            text-decoration: none; none;
        }
        td {
            border: solid 1px #DDEEEE;
            color: #333;
            padding 10px;
            text-shadow: 1px 1px 1px #fff;
        }
        a{
            background-color: #47C0DB;
            color: #fff;
            padding: 10px;
            text-decoration: none;
            font-size: 11px;
        }
        .navigasi {
    display: flex;
    justify-content: center; /* Pusatkan secara horizontal */
    align-items: center; /* Pusatkan secara vertikal */
    margin-top: 20px; /* Atur jarak atas sesuai kebutuhan */
}

.navigasi a {
    margin: 0 10px; /* Atur jarak antara tombol */
    text-decoration: none;
}

.navigasi button {
    padding: 8px 16px;
    background-color: #3498db;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

.navigasi button:hover {
    background-color: #2980b9; /* Warna saat tombol dihover */
}
form {
    display: flex;
    justify-content: center; /* Pusatkan secara horizontal */
    margin-top: 20px; /* Atur jarak atas sesuai kebutuhan */
    
}

input[type="text"] {
    padding: 8px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 4px 0 0 4px;
}

input[type="submit"] {
    padding: 8px 16px;
    background-color: #3498db;
    color: #fff;
    border: none;
    border-radius: 0 4px 4px 0;
    cursor: pointer;
    font-size: 14px;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #2980b9; /* Warna saat tombol dihover */
}
h3 {
    text-transform : uppercase;
    color: #47C0DB;
    text-align: center;
    background-color:#DDEEEE;
}
h4 {
    text-transform : uppercase;
    color: #47C0DB;
    text-align: center;
    background-color:#DDEEEE;
}
<style>
        body {
        font-family: Arial, Helvetica, sans-serif;
        }

        .navbar {
        overflow: hidden;
        background-color: #47C0DB;
        }

        .navbar a {
        float: left;
        font-size: 16px;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        }

        .dropdown {
        float: left;
        overflow: hidden;
        }

        .dropdown .dropbtn {
        font-size: 16px;  
        border: none;
        outline: none;
        color: white;
        padding: 14px 16px;
        background-color: inherit;
        font-family: inherit;
        margin: 0;
        }

        .navbar a:hover, .dropdown:hover .dropbtn {
        background-color: azure;
        color: black;
        }

        .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
        }

        .dropdown-content a {
        float: none;
        color: white;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
        }

        .dropdown-content a:hover {
        background-color: #ddd;
        }

        .dropdown:hover .dropdown-content {
        display: block;
        }
    </style>
    </style>
</head>
<body>
    <header>

    </header>
	<div class="navbar">
        <a href="index.php">Home</a>
        <div class="dropdown">
            <button class="dropbtn">Kelola Data 
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
            <a href="gudang/gudang.php">Data Gudang</a>
            <a href="tampil.php">Data Barang</a>
            <a href="">Data Pengguna</a>
            <a href="customer/customer.php">Data Customer</a>
            <a href="supplier/supplier.php">Data Suppllier</a>
            </div>
    </div>
    <div class="dropdown">
            <button class="dropbtn">Kelola Transaksi 
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
            <a href="transaksi/beli.php">Transaksi Pembelian</a>
            <a href="transaksi/jual.php">Transaksi Penjualan</a>
            </div>
    </div>
    <div class="dropdown">
            <button class="dropbtn">Kelola Laporan
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
            <a href=""></a>
            <a href="tampil.php">Laporan Transaksi Penjualan</a>
            <a href="tampil.php">Laporan Transaksi Pembelian</a>
            </div>
    </div>
        <a href="login.php">Logout</a>
    </div>
    
    <div class="container">
        <?php if ($loggedIn) { ?>
            <h3>Anda sudah login</h3>
            <h4>Sebagai : Admin</h4>
        <?php } else { ?>
            <div class="login-container">
                <h3>Form Login</h3>
                <div class="login-form">
                    <form method="post" action="index.php">
                        <table>
                            <tr>
                                <td>Username</td>
                                <td>:</td>
                                <td><input type="text" name="username"/></td>
                            </tr>
                            <tr>
                                <td>Password</td>
                                <td>:</td>
                                <td><input type="password" name="password"/></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td><input type="submit" name="login" value="Login"/></td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        <?php } ?>
    </div>
        </br>
        </br>
        </br>
        </br>
        </br>
        </br>
    <h1>Selamat Datang di Sistem Manajemen Gudang</h1>
</body>
</html>
