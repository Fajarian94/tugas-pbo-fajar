<?php
session_start();

include('koneksi.php');
$db = new database();

function authenticateUser($username, $password) {
    $mysqli = new mysqli('localhost', 'root', '', 'belajar_oop');

    if ($mysqli->connect_error) {
        die('Koneksi database gagal: ' . $mysqli->connect_error);
    }

    $query = "SELECT * FROM user WHERE username = ? AND password = ?";
    $statement = $mysqli->prepare($query);

    // Bind parameter ke statement
    $statement->bind_param("ss", $username, $password);

    // Eksekusi statement
    $statement->execute();

    // Ambil hasil dari statement
    $result = $statement->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id_user'];
        $statement->close();
        $mysqli->close();
        return true;
    } else {
        $statement->close();
        $mysqli->close();
        return false;
    }
}

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (authenticateUser($username, $password)) {
        header('Location: index.php'); // Jika autentikasi berhasil, arahkan ke halaman utama
        exit();
    } else {
        $error = "Username atau password salah"; // Tampilkan pesan error jika autentikasi gagal
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column; /* Menggunakan flex-direction column agar konten terpusat secara vertikal */
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .logo {
            margin-bottom: 20px; /* Memberikan margin antara logo dan form */
            text-align: center;
        }

        .login-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        .login-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .login-form label {
            display: block;
            margin-bottom: 6px;
        }

        .login-form input[type="text"],
        .login-form input[type="password"],
        .login-form input[type="submit"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .login-form input[type="submit"] {
            background-color: #007bff;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-form input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="logo">
    <img src="gambar/logo_aplikasi.png" alt="Logo Aplikasi" style="width: 120px;">
    </div>
    <div class="login-container">
        <h2>Form Login</h2>
        <?php if (isset($error)) { ?>
            <p class="error-message"><?php echo $error; ?></p>
        <?php } ?>
        <form class="login-form" method="post" action="index.php">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username">

            <label for="password">Password:</label>
            <input type="password" id="password" name="password">

            <input type="submit" name="login" value="Login">
        </form>
    </div>
</body>
</html>
