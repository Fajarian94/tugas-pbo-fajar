<?php
include('koneksi.php');
$koneksi = new database();

$action = $_GET['action'];

if($action == "add")
{
$koneksi->tambah_data($_POST['id_gudang'],$_POST['kode_gudang'],$_POST['nama_gudang'],$_POST['lokasi']);
header('location:gudang.php');
}

else if ($action == "edit")
{
$id_gudang = $_GET['id_gudang'];
$koneksi->edit_data($_POST['kode_gudang'],$_POST['nama_gudang'],$_POST['lokasi']);
header('location:gudang.php');
}

else if ($action == "delete")
{
$id_gudang = $_GET['id_gudang'];
$koneksi->delete_data($id_gudang);
header('location:gudang.php');
}

else if ($action == "search")
{
$nama_gudang = $_POST['nama_gudang'];
$koneksi->cari_data($nama_gudang);
header('location:gudang.php');

}else if ($action == "logout"){
    $koneksi->logout();
    }

?>