<?php
include('koneksi.php');
$db = new database();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Data Gudang</title>
        <style type = "text/css">
            from#background_border{
                margin:0px 230px;
                color:white
            }

        </style>
    </head>
    <body>
        <h2>Data Gudang</h2>
        <table width="667"  border="1">
            <tr>
                <th width="21">ID Gudang</th>
                <th width="122">Kode Gudang</th>
                <th width="158">Nama Gudang</th>
                <th width="47">Lokasi</th>
            </tr>
            <?php
            $data_barang = $db->tampil_data();
            $no = 1;
            foreach($data_barang as $row){
            ?>
            <tr>
                <td><?php echo $row['id_gudang']; ?></td>
                <td><?php echo $row['kode_gudang']; ?></td>
                <td><?php echo $row['nama_gudang']; ?></td>
                <td><?php echo $row['lokasi']; ?></td>

            </tr>

            <?php
            } ?>
        </table>
        <script>
            window.print();
        </script>
        <tr>
        <a href="customer.php">
        <input type="button" name="tombol" value="Kembali"/>
        </a>
        </td>
        </tr>
    </body>
</html>