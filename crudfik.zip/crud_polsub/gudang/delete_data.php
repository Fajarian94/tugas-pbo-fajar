<?php
include('koneksi.php');
$db = new database();
$id_gudang = $_GET['id_gudang'];
$data_edit_gudang = $db->delete_data($id_gudang);

?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <h3>Form Edit Data gudang</h3>
    <hr/>
    <form method="post" action="proses_gudang.php?action=edit&id_gudang=<?php echo $id_barang;?>">
    <?php
    foreach($data_edit_gudang as $d){
    ?>
    <table>
    <tr>
            <td>ID Gudang</td>
            <td>:</td>
            <td>
            <input type="text" name="id_gudang" value="<?php echo $d['id_gudang']; ?>">
        </tr>
        <tr>
            <td>kode Gudang</td>
            <td>:</td>
            <td>
            <input type="text" name="kode_gudang" value="<?php echo $d['kode_gudang']; ?>"></td>
        </tr>
        <tr>
            <td>Nama Gudang</td>
            <td>:</td>
            <td>
            <input type="text" name="nama_gudang" value="<?php echo $d['nama_gudang']; ?>"></td>
        </tr>
        <tr>
            <td>Lokasi</td>
            <td>:</td>
            <td>
            <input type="text" name="lokasi" value="<?php echo $d['lokasi']; ?>"></td>
        </tr>
        
        <tr>
            <td></td>
            <td></td>
            <td>
            <input type="submit" name="tombol" value="Ubah"/>
            <a href="tampil_data.php">
            <input type="submit" name="tombol" value="Kembali"/>
            </a>
        </td>
        </tr>
    </table>
    <?php
    }
    ?>
</form>
</body>
</html>