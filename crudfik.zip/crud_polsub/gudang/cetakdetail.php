<?php
include('koneksi.php');
$db = new database();

if (isset($_POST['cetak'])) {
    $id_gudang = $_POST['cetak'];
    $data_gudang = $db->cari_datas($id_gudang); // Mengambil data berdasarkan kode barang

    if ($id_gudang) {
        // Jika data ditemukan, tampilkan informasi
        echo "<h2>Detail Barang</h2>";
        foreach ($data_customer as $row) {
            echo "<p>ID Gudang: " . $row['id_gudang'] . "</p>";
            echo "<p>ID Gudang: " . $row['kode_gudang'] . "</p>";
            echo "<p>ID Gudang: " . $row['nama_gudang'] . "</p>";
            echo "<p>ID Gudang: " . $row['lokasi'] . "</p>";
        }
        
        // Tombol untuk mencetak
        echo "<button onclick='window.print()'>Cetak</button>";

    } else {
        // Jika tidak ada data ditemukan
        echo "<p>Data tidak ditemukan untuk kode gudang '$kode_gudang'.</p>";
    }
}
?>
