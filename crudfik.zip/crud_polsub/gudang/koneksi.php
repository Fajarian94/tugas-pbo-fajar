<?php
class database {
    var $host = "localhost";
    var $username = "root";
    var $password = "";
    var $database = "belajar_oop";
    var $koneksi = "";

    function __construct() {
        $this->koneksi = mysqli_connect($this->host, $this->username, $this->password, $this->database);
        if (mysqli_connect_error()) {
            echo "Koneksi database gagal : " . mysqli_connect_error();
        }
    }

    function tampil_data(){
        $data = mysqli_query($this->koneksi,"select * from tb_gudang");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }

    function tambah_data($id_gudang, $kode_gudang, $nama_gudang, $lokasi){
        mysqli_query($this->koneksi,"insert into tb_gudang values ('$id_gudang', '$kode_gudang', '$nama_gudang', '$lokasi')");
    }

    function tampil_edit_data($id_gudang){
        $data = mysqli_query($this->koneksi,"select * from tb_gudang where id_gudang ='$id_gudang'");
        while($d = mysqli_fetch_array($data)){
            $hasil[] = $d;
        }
        return $hasil;
    }

    function edit_data ($id_gudang, $nama_gudang, $lokas){
        mysqli_query($this->koneksi,"update tb_gudang set kode_gudang = '$kode_gudang' , nama_gudang = '$nama_gudang', lokasi= '$lokasi' where id_gudang='$id_gudang'");
    }

    function delete_data($id_gudang){
        mysqli_query($this->koneksi, "delete from tb_gudang where id_gudang='$id_gudang'");
    }

    function cari_data($nama_gudang){
        $data = mysqli_query($this->koneksi,"select * from tb_gudang where nama_gudang='$nama_gudang'");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    function id_gudang() {
        $data = mysqli_query($this->koneksi, "SELECT id_gudang FROM tb_gudang ORDER BY id_gudang DESC LIMIT 1");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    function cari_datas($id_gudang){
        $query = "SELECT * FROM tb_gudang WHERE id_gudang = '$id_gudang'";
        $data = mysqli_query($this->koneksi, $query);
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    function tampil_data_cari($nama)
    {
        $data = mysqli_query($this->koneksi, "select * from tb_gudang where nama_gudang like '%$nama%'");
        $hasil = [];
        while ($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    function cetak_data($id_gudang) {
        $query = "SELECT * FROM tb_gudang WHERE id_gudang = '$id_gudang'";
        $data = mysqli_query($this->koneksi, $query);
        return $data;
    }
    function tampil_datas(){
        $data = mysqli_query($this->koneksi,"SELECT * FROM tb_gudang");
        while($row = mysqli_fetch_assoc($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
}

?>

