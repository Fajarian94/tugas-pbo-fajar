<?php
include('koneksi.php'); 

$db = new database(); 
$id_gudang = $db->id_gudang();
$kode_gudang_terakhir = '';

foreach ($id_gudang as $row) {
    $kode_max = $row['id_gudang'];
    $pecahdata = explode('GD', $kode_max);
    $kode_number = (int)$pecahdata[1]; // Using null coalescing operator for safer assignment

    // Menambahkan angka 1 ke kode terakhir
    $next_number = $kode_number + 1;

    // Mengonversi angka menjadi string dengan tetap mempertahankan panjangnya
    $next_code = 'GD' . sprintf("%02d", $next_number);

    // Simpan kode barang terakhir
    $kode_gudang_terakhir = $next_code;
}
?>



<!DOCTYPE html>
<html>
<head>
    <title>Form Tambah Data gudang</title>
</head>
<body>
    <h3>Form Tambah Data gudang</h3>
    <hr/>
    <form method="post" action="proses_gudang.php?action=add">
    <table>
    <tr>
            <td>ID gudang</td>
            <td>:</td>
            <td>
            <input type="text" name="id_gudang" value= "<?php echo $kode_gudang_terakhir;?>" readonly/></td>
        </tr>
        <tr>
            <td>Kode gudang</td>
            <td>:</td>
            <td>
            <input type="text" name="kode_gudang"/></td>
        </tr>
        <tr>
            <td>Nama gudang</td>
            <td>:</td>
            <td>
            <input type="text" name="nama_gudang"></td>
        </tr>
        <tr>
            <td>Lokasi</td>
            <td>:</td>
            <td>
            <input type="text" name="lokasi"></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td>
            <td><input type="submit" name="tombol" value="Simpan"/>
            <a href="gudang.php">
            <input type="button" name="tombol" value="Kembali"/>
            </a>
        </td>
        </tr>
    </table>
</form>
</body>
</html>
