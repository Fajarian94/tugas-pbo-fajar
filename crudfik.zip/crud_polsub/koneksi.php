<?php

class database {
    var $host = "localhost";
    var $username = "root";
    var $password = "";
    var $database = "belajar_oop";
    var $koneksi = "";

    function __construct(){
        $this->koneksi = mysqli_connect($this->host, $this->username, $this->password, $this->database);
        if(mysqli_connect_error()){
            echo "Koneksi database gagal : ". mysqli_connect_error(); 
        }
    }

    #INI UNTUK BARANG
    function tampil_data(){
        $data = mysqli_query($this->koneksi,"select * from tb_barang");
        while ($row = mysqli_fetch_array($data)) {
            $hasil[] = $row;
        }
        return $hasil;
    }

    function autoTampil(){
        $data = mysqli_query ($this->koneksi, "select nama_barang from tb_barang");
        while ($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }

    function tambah_data ($kode_barang, $nama_barang, $stok, $harga_beli, $harga_jual, $gambar_produk) {
        if ($gambar_produk != ""){
            $allow_ext = array ('png', 'jpg', 'jpeg');
            $x = explode ('.', $gambar_produk);
            $ext = strtolower(end($x));
            $file_tmp = $_FILES['gambar_produk']['tmp_name'];
            $rand_num = rand (1,999);
            $nama_gambar_baru = $rand_num.'-'.$gambar_produk;
            if  (in_array($ext, $allow_ext) === true) {
                move_uploaded_file ($file_tmp, 'gambar/'.$nama_gambar_baru);
                $query = "INSERT INTO tb_barang (id_barang, kode_barang, nama_barang, stok, harga_beli, harga_jual, gambar_produk) VALUES ('','$kode_barang', '$nama_barang', '$stok', '$harga_beli', '$harga_jual', '$nama_gambar_baru')";
                $result = mysqli_query($this->koneksi, $query);
                if (!$result) {
                    die ("Query gagal dijalankan: ".mysqli_errno($this->koneksi)." - ".mysqli_error($this->koneksi));
                }
                else {
                    echo "<script>alert('Data berhasil ditambah.');window.location='tampil.php';</script>";
                }
            }
            else {
                echo "<script>alert('Ekstensi gambar yang boleh hanya jpg, jpeg atau png.');window.location='tambah_data.php';</script>";
            }
        }
        else {
            $query = "INSERT INTO tb_barang (id_barang, kode_barang, nama_barang, stok, harga_beli, harga_jual, gambar_produk) VALUES ('','$kode_barang', '$nama_barang', '$stok', '$harga_beli', '$harga_jual', null}";
            $result = mysqli_query($this->koneksi, $query);
            if (!$result) {
                die ("Query gagal dijalankan: ".mysqli_errno($this->koneksi)." - ".mysqli_error($this->koneksi));
            }
            else {
                echo "<script>alert('Data berhasil ditambah.');window.location='tampil.php';</script>";
            }
        }
    }

    function tampil_edit_data ($id_barang) {
        $data = mysqli_query($this->koneksi, "select * from tb_barang where id_barang='$id_barang'");
        while ($d = mysqli_fetch_array($data)) {
            $hasil [] = $d;
        }
        return $hasil;
    }

    function edit_data ($id_barang, $nama_barang, $stok, $harga_beli, $harga_jual, $gambar_produk){
        if ($gambar_produk != ""){
            $allow_ext = array ('png', 'jpg', 'jpeg');
            $x = explode ('.', $gambar_produk);
            $ext = strtolower(end($x));
            $file_tmp = $_FILES['gambar_produk']['tmp_name'];
            $rand_num = rand (1,999);
            $nama_gambar_baru = $rand_num.'-'.$gambar_produk;
            if  (in_array($ext, $allow_ext) === true) {
                move_uploaded_file ($file_tmp, 'gambar/'.$nama_gambar_baru);
                $query = "UPDATE tb_barang SET nama_barang='$nama_barang', stok = '$stok', harga_beli='$harga_beli', harga_jual ='$harga_jual', gambar_produk = '$nama_gambar_baru'";
                $query .="WHERE id_barang = '$id_barang'";
                $result = mysqli_query ($this->koneksi, $query);
                if (!$result) {
                    die ("Query gagal dijalankan: ".mysqli_errno($this->koneksi)." - ".mysqli_error($this->koneksi));
                }
                else {
                    echo "<script>alert('Data berhasil diubah.');window.location='tampil.php';</script>";
                }
            }
            else {
                echo "<script>alert('Ekstensi gambar yang boleh hanya jpg, jpeg atau png.');window.location='edit_data.php';</script>";
            }
        }
        else {
            $query = "UPDATE tb_barang SET nama_barang='$nama_barang', stok = '$stok', harga_beli='$harga_beli', harga_jual ='$harga_jual'";
            $query .="WHERE id_barang = '$id_barang'";
            $result = mysqli_query ($this->koneksi, $query);
            if (!$result) {
                die ("Query gagal dijalankan: ".mysqli_errno($this->koneksi)." - ".mysqli_error($this->koneksi));
            }
            else {
                echo "<script>alert('Data berhasil diubah.');window.location='tampil.php';</script>";
            }
        }
    }

    function page($start, $jmlitem){
        $data = mysqli_query($this->koneksi, "select * from tb_barang LIMIT $start, $jmlitem");
        while ($row = mysqli_fetch_array($data)) {
            $hasil[] = $row;
        }
        return $hasil;
    }
    function delete_data ($id_barang) {
        mysqli_query($this->koneksi, "delete from tb_barang where id_barang = '$id_barang'");
    }


    function cari_data ($cari,$kriteria) {
        $data = mysqli_query ($this->koneksi, "select * from tb_barang where $kriteria = '$cari'");
        if($kriteria == 'nama_barang') {

        }
        while ($row = mysqli_fetch_array($data)) {
            $hasil[] = $row;        
        }
        return $hasil;
    }

    function kode_barang (){
        $data = mysqli_query ($this->koneksi, "SELECT MAX(kode_barang) AS kode_barang FROM tb_barang");
            while ($row = mysqli_fetch_array($data)) {
                $hasil[] = $row;
            }
            return $hasil;
    }

    function login($username, $password){
        $username = $_POST['username'];
        $password = $_POST['password'];
    
        $data = mysqli_query($this->koneksi, "SELECT * FROM user WHERE username='$username' AND password='$password'");
        $user = mysqli_fetch_assoc($data);
    
        if ($user) {
            $_SESSION['username'] = $user['username'];
            $_SESSION['tipe_user'] = $user['tipe_user']; 
            header("location: tampil.php?pesan=Selamat Datang " . $user['tipe_user']);
        } else {
            header("location: index.php?pesan=gagal login");
        }
    }
    

    function logout(){
        unset($_SESSION["username"]);
        session_unset();
        session_destroy();
        header ("location:index.php");
    }

    function cetak_satuan ($nama_barang){
        $data = mysqli_query ($this->koneksi, "select * from tb_barang where nama_barang = '$nama_barang'");
        while ($d = mysqli_fetch_array($data)) {
            $hasil[] = $d;
        }
        return $hasil;
    }


}



?>