<?php
include('koneksi.php');
$db = new database();

if (isset($_POST['cetak'])) {
    $id_customer = $_POST['cetak'];
    $data_customer = $db->cari_datas($id_customer); // Mengambil data berdasarkan kode barang

    if ($id_customer) {
        // Jika data ditemukan, tampilkan informasi
        echo "<h2>Detail Barang</h2>";
        foreach ($data_customer as $row) {
            echo "<p>ID Customer: " . $row['id_customer'] . "</p>";
            echo "<p>NIK Customer: " . $row['nik_customer'] . "</p>";
            echo "<p>Nama Customer: " . $row['nama_customer'] . "</p>";
            echo "<p>Jenis Kelamin: " . $row['jenis_kelamin'] . "</p>";
            echo "<p>Alamat Customer: " . $row['alamat_customer'] . "</p>";
            echo "<p>Telepon Customer: " . $row['telepon_customer'] . "</p>";
            echo "<p>Email Customer: " . $row['email_customer'] . "</p>";
            echo "<p>Password Customer: " . $row['password_customer'] . "</p>";
        }
        
        // Tombol untuk mencetak
        echo "<button onclick='window.print()'>Cetak</button>";

    } else {
        // Jika tidak ada data ditemukan
        echo "<p>Data tidak ditemukan untuk kode barang '$kode_barang'.</p>";
    }
}
?>
