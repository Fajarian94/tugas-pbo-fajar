<?php
include('koneksi.php');
$koneksi = new database();

$action = $_GET['action'];

if($action == "add")
{
$koneksi->tambah_data($_POST['id_customer'],$_POST['nik_customer'],$_POST['nama_customer'],$_POST['jenis_kelamin'],$_POST['alamat_customer'],$_POST['telepon_customer'],$_POST['email_customer'],$_POST['password_customer']);
header('location:customer.php');
}

else if ($action == "edit")
{
$id_customer = $_GET['id_customer'];
$koneksi->edit_data($_POST['id_customer'],$_POST['nik_customer'],$_POST['nama_customer'],$_POST['jenis_kelamin'],$_POST['alamat_customer'],$_POST['telepon_customer'],$_POST['email_customer'],$_POST['password_customer']);
header('location:customer.php');
}

else if ($action == "delete")
{
$id_customer = $_GET['id_customer'];
$koneksi->delete_data($id_customer);
header('location:customer.php');
}

else if ($action == "search")
{
$nama_customer = $_POST['nama_customer'];
$koneksi->cari_data($nama_customer);
header('location:customer.php');
}

?>