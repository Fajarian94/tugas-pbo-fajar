<?php
include('koneksi.php');
$db = new database();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Customer</title>
    <style type="text/css">
        form#background_border{
            margin: 0px 500px;
            color:black;
        }
        .button-group {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .button-group > * {
            margin-right: 10px;
            align: center;
        }
        *{
            font-family:"Trebuchat MS";
        }
        h1 {
            text-transform : uppercase;
            color: #47C0DB;
            text-align: center;
        }
        table{
            border: solid 1px = #DDEEEE;
            border-collapse: collapse;
            border-spacing: 0;
            width 70%;
            margin: 10px auto 10x auto;
        }
        th {
            background-color: #DDEFEF;
            border: solid 1px #DDEEEE;
            color: #336B6B;
            padding: 10px;
            text-align: left;
            text-shadow: 1px 1px 1px #fff;
            text-decoration: none; none;
        }
        td {
            border: solid 1px #DDEEEE;
            color: #333;
            padding 10px;
            text-shadow: 1px 1px 1px #fff;
        }
        a{
            background-color: #47C0DB;
            color: #fff;
            padding: 10px;
            text-decoration: none;
            font-size: 11px;
        }
        .navigasi {
    display: flex;
    justify-content: center; /* Pusatkan secara horizontal */
    align-items: center; /* Pusatkan secara vertikal */
    margin-top: 20px; /* Atur jarak atas sesuai kebutuhan */
}

.navigasi a {
    margin: 0 10px; /* Atur jarak antara tombol */
    text-decoration: none;
}

.navigasi button {
    padding: 8px 16px;
    background-color: #3498db;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

.navigasi button:hover {
    background-color: #2980b9; /* Warna saat tombol dihover */
}
form {
    display: flex;
    justify-content: center; /* Pusatkan secara horizontal */
    margin-top: 20px; /* Atur jarak atas sesuai kebutuhan */
    
}

input[type="text"] {
    padding: 8px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 4px 0 0 4px;
}

input[type="submit"] {
    padding: 8px 16px;
    background-color: #3498db;
    color: #fff;
    border: none;
    border-radius: 0 4px 4px 0;
    cursor: pointer;
    font-size: 14px;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #2980b9; /* Warna saat tombol dihover */
}
body {
        font-family: Arial, Helvetica, sans-serif;
        }

        .navbar {
        overflow: hidden;
        background-color: #47C0DB;
        }

        .navbar a {
        float: left;
        font-size: 16px;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        }

        .dropdown {
        float: left;
        overflow: hidden;
        }

        .dropdown .dropbtn {
        font-size: 16px;  
        border: none;
        outline: none;
        color: white;
        padding: 14px 16px;
        background-color: inherit;
        font-family: inherit;
        margin: 0;
        }

        .navbar a:hover, .dropdown:hover .dropbtn {
        background-color: azure;
        color: black;
        }

        .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
        }

        .dropdown-content a {
        float: none;
        color: white;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
        }

        .dropdown-content a:hover {
        background-color: #ddd;
        }

        .dropdown:hover .dropdown-content {
        display: block;
        }
    </style>
    
</head>
<body>
<header>

    </header>

    <div class="navbar">
        <a href="../index.php">Home</a>
        <div class="dropdown">
            <button class="dropbtn">Kelola Data 
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
            <a href="gudang.php">Data Gudang</a>
            <a href="../tampil.php">Data Barang</a>
            <a href="../customer/customer.php">Data Customer</a>
            <a href="../supplier/supplier.php">Data Suppllier</a>
            </div>
    </div>
    <div class="dropdown">
            <button class="dropbtn">Kelola Transaksi 
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
            <a href="../transaksi/beli.php">Transaksi Pembelian</a>
            <a href="../transaksi/jual.php">Transaksi Penjualan</a>
            </div>
    </div>
    <div class="dropdown">
            <button class="dropbtn">Kelola Laporan
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
            <a href=""></a>
            <a href="tampil.php">Laporan Transaksi Penjualan</a>
            <a href="tampil.php">Laporan Transaksi Pembelian</a>
            </div>
    </div>
        <a href="../login.php">Logout</a>
    </div>
        <br>
        
        <div class="button-group">
            <a href="tambah_data.php"><button>Tambah Data</button></a>
            <a href="cetak.php"><button>Cetak Data</button></a>
            <form method="get">
                <input type="text" name="cari" placeholder="Cari Nama Customer">
                <input type="submit" value="Cari">
            </form>
        </div>
        <?php
        if(isset($_GET['cari'])){
            $cari = $_GET['cari'];
            $data_barang = $db->tampil_data_cari($cari);
        }else{
            $data_barang = $db->tampil_data();
        }?>
        <?php
        if (isset($_GET['cari'])) {
            $cari = $_GET['cari'];
            echo "<b>Hasil pencarian : " . $cari . "</b>";
        }
        ?>
        <h1>Data Customer</h1>
        <table border="1">
            <tr>
                <th>ID Customer</th>
                <th>NIK Customer</th>
                <th>Nama Customer</th>
                <th>Jenis Kelamin</th>
                <th>Alamat Customer</th>
                <th>Telepon Customer</th>
                <th>Email Customer</th>
                <th>Password Customer</th>
                <th>Action</th>
            </tr>
            <?php
            $no = 1;
            foreach ($data_barang as $row) {
            ?>
                <tr>
                    <td><?php echo $row['id_customer']; ?></td>
                    <td><?php echo $row['nik_customer']; ?></td>
                    <td><?php echo $row['nama_customer']; ?></td>
                    <td><?php echo $row['jenis_kelamin']; ?></td>
                    <td><?php echo $row['alamat_customer']; ?></td>
                    <td><?php echo $row['telepon_customer']; ?></td>
                    <td><?php echo $row['email_customer']; ?></td>
                    <td><?php echo $row['password_customer']; ?></td>
                    <td>
                        <a href="edit_data.php?id_customer=<?php echo $row['id_customer']; ?>&action=edit">Edit</a>
                        <a href="proses_customer.php?id_customer=<?php echo $row['id_customer']; ?>&action=delete">Hapus</a>
                    </td>
                </tr>
            <?php
            }
            ?>
        </table>


        <form method="post" action="cetakdetail.php">
            <input type="text" name="cetak" placeholder="Masukkan Kode Customer">
            <input type="submit" value="Cetak">
        </form>




</body>
</html>
