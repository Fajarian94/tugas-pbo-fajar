<?php
class database {
    var $host = "localhost";
    var $username = "root";
    var $password = "";
    var $database = "belajar_oop";
    var $koneksi = "";

    function __construct() {
        $this->koneksi = mysqli_connect($this->host, $this->username, $this->password, $this->database);
        if (mysqli_connect_error()) {
            echo "Koneksi database gagal : " . mysqli_connect_error();
        }
    }

    function tampil_data(){
        $data = mysqli_query($this->koneksi,"select * from tb_customer");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }

    function tambah_data($id_customer, $nik_customer, $nama_customer, $jenis_kelamin, $alamat_customer, $telepon_customer, $email_customer, $password_customer){
        mysqli_query($this->koneksi,"insert into tb_customer values ('$id_customer', '$nik_customer', '$nama_customer', '$jenis_kelamin', '$alamat_customer', '$telepon_customer', '$email_customer', '$password_customer')");
    }

    function tampil_edit_data($id_customer){
        $data = mysqli_query($this->koneksi,"select * from tb_customer where id_customer ='$id_customer'");
        while($d = mysqli_fetch_array($data)){
            $hasil[] = $d;
        }
        return $hasil;
    }

    function edit_data($id_customer, $nik_customer, $nama_customer, $jenis_kelamin, $alamat_customer, $telepon_customer, $email_customer, $password_customer){
        mysqli_query($this->koneksi,"update tb_customer set nik_customer = '$nik_customer', nama_customer = '$nama_customer', jenis_kelamin = '$jenis_kelamin', alamat_customer = '$alamat_customer', telepon_customer = '$telepon_customer', email_customer = '$email_customer', password_customer = '$password_customer' where id_customer='$id_customer'");
    }

    function delete_data($id_customer){
        mysqli_query($this->koneksi, "delete from tb_customer where id_customer='$id_customer'");
    }

    function cari_data($nama_customer){
        $data = mysqli_query($this->koneksi,"select * from tb_customer where nama_customer='$nama_customer'");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    function id_customer() {
        $data = mysqli_query($this->koneksi, "SELECT id_customer FROM tb_customer ORDER BY id_customer DESC LIMIT 1");
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    function cari_datas($id_customer){
        $query = "SELECT * FROM tb_customer WHERE id_customer = '$id_customer'";
        $data = mysqli_query($this->koneksi, $query);
        while($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    function tampil_data_cari($nama)
    {
        $data = mysqli_query($this->koneksi, "select * from tb_customer where nama_customer like '%$nama%'");
        $hasil = [];
        while ($row = mysqli_fetch_array($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
    function cetak_data($id_customer) {
        $query = "SELECT * FROM tb_customer WHERE id_customer = '$id_customer'";
        $data = mysqli_query($this->koneksi, $query);
        return $data;
    }
    function tampil_datas(){
        $data = mysqli_query($this->koneksi,"SELECT * FROM tb_customer");
        while($row = mysqli_fetch_assoc($data)){
            $hasil[] = $row;
        }
        return $hasil;
    }
}

?>

