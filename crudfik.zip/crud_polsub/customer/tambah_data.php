<?php
include('koneksi.php'); 

$db = new database(); 

$id_customer = $db->id_customer();
$kode_customer_terakhir = '';

foreach ($id_customer as $row) {
    $kode_max = $row['id_customer'];
    $pecahdata = explode('CST0', $kode_max);
    $kode_number = (int)$pecahdata[1] ?? 0; // Using null coalescing operator for safer assignment

    // Menambahkan angka 1 ke kode terakhir
    $next_number = $kode_number + 1;

    // Mengonversi angka menjadi string dengan tetap mempertahankan panjangnya
    $next_code = 'CST0' . sprintf("%02d", $next_number);

    // Simpan kode barang terakhir
    $kode_customer_terakhir = $next_code;
}
?>



?>
<!DOCTYPE html>
<html>
<head>
    <title>Form Tambah Data Customer</title>
</head>
<body>
    <h3>Form Tambah Data Customer</h3>
    <hr/>
    <form method="post" action="proses_customer.php?action=add">
    <table>
        <tr>
            <td>ID Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="id_customer" value= "<?php echo $kode_customer_terakhir; ?>" readonly/></td>
        </tr>
        <tr>
            <td>NIK Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="NIK_customer"></td>
        </tr>
        <tr>
            <td>Nama Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="nama_customer"></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>:</td>
            <td>
            <input type="text" name="jenis_kelamin"></td>
        </tr>
        <tr>
            <td>Alamat Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="alamat_customer"></td>
        </tr>
        <tr>
            <td>Telepon Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="telpon_customer"></td>
        </tr>
        <tr>
            <td>Email Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="emai_customer"></td>
        </tr>
        <tr>
            <td>Password Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="password_customer"></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td>
            <td><input type="submit" name="tombol" value="Simpan"/>
            <a href="customer.php">
            <input type="button" name="tombol" value="Kembali"/>
            </a>
        </td>
        </tr>
    </table>
</form>
</body>
</html>
