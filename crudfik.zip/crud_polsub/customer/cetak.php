<?php
include('koneksi.php');
$db = new database();
?>
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <style type = "text/css">
            from#background_border{
                margin:0px 230px;
                color:white
            }

        </style>
    </head>
    <body>
        <h2>LAPORAN DATA BARANG CV JAYA</h2>
        <table width="667"  border="1">
            <tr>
                <th width="21">ID Customer</th>
                <th width="122">NIK Customer</th>
                <th width="158">Nama Customer</th>
                <th width="47">Jenis Kealamin</th>
                <th width="76">Alamat Customer</th>
                <th width="83">Telpon Customer</th>
                <th width="114">Email Customer</th>
                <th width="114">Password Customer</th>
            </tr>
            <?php
            $data_barang = $db->tampil_data();
            $no = 1;
            foreach($data_barang as $row){
            ?>
            <tr>
                <td><?php echo $row['id_customer']; ?></td>
                <td><?php echo $row['nik_customer']; ?></td>
                <td><?php echo $row['nama_customer']; ?></td>
                <td><?php echo $row['jenis_kelamin']; ?></td>
                <td><?php echo $row['alamat_customer']; ?></td>
                <td><?php echo $row['telepon_customer']; ?></td>
                <td><?php echo $row['email_customer']; ?></td>
                <td><?php echo $row['email_customer']; ?></td>
            </tr>

            <?php
            } ?>
        </table>
        <script>
            window.print();
        </script>
        <tr>
        <a href="customer.php">
        <input type="button" name="tombol" value="Kembali"/>
        </a>
        </td>
        </tr>
    </body>
</html>