<?php
include('koneksi.php');
$db = new database();
$id_customer = $_GET['id_customer'];
$data_edit_customer = $db->delete_data($id_customer);

?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <h3>Form Edit Data Customer</h3>
    <hr/>
    <form method="post" action="proses_customer.php?action=edit&id_customer=<?php echo $id_barang;?>">
    <?php
    foreach($data_edit_customer as $d){
    ?>
    <table>
    <tr>
            <td>ID Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="id_customer" value="<?php echo $d['id_customer']; ?>">
        </tr>
        <tr>
            <td>NIK Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="NIK_customer" value="<?php echo $d['nik_customer']; ?>"></td>
        </tr>
        <tr>
            <td>Nama Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="nama_customer" value="<?php echo $d['nama_customer']; ?>"></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>:</td>
            <td>
            <input type="text" name="jenis_kelamin" value="<?php echo $d['jenis_kelamin']; ?>"></td>
        </tr>
        <tr>
            <td>Alamat Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="alamat_customer" value="<?php echo $d['alamat_customer']; ?>"></td>
        </tr>
        <tr>
            <td>Telepon Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="telpon_customer" value="<?php echo $d['telepon_customer']; ?>"></td>
        </tr>
        <tr>
            <td>Email Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="emai_customer" value="<?php echo $d['email_customer']; ?>"></td>
        </tr>
        <tr>
            <td>Password Customer</td>
            <td>:</td>
            <td>
            <input type="text" name="password_customer" value="<?php echo $d['password_customer']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td>
            <input type="submit" name="tombol" value="Ubah"/>
            <a href="tampil_data.php">
            <input type="submit" name="tombol" value="Kembali"/>
            </a>
        </td>
        </tr>
    </table>
    <?php
    }
    ?>
</form>
</body>
</html>